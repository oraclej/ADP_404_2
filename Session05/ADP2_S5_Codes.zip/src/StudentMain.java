public class StudentMain {
    public static void main(String[] args) {
//        Student ali = new Student();
//        Student reza = new Student();
//        Student maryam = new Student();
//        ali.name = "Ali";
//        reza.name = "Reza";
//        Student.conditionalGpa = 13;
        System.out.println(Student.CONDITIONAL_GPA);
    }
}
