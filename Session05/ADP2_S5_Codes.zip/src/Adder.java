public class Adder {



    public static void main(String[] args) {
        add(2,3);
    }

    public static int add(int a, int b){
        return a+b;
    }
}
