public class Customer {
    String name;
    String address;
    int age;
}
