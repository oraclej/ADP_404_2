public class One {
    public static void main(String[] args) {
        byte b = 20;
        int n = b;

        int t = 200;
        byte m = (byte)t;
        System.out.println(m);


    }
}
